// background.js (service worker)
chrome.runtime.onInstalled.addListener(() => {
  // Crear el item del menu contextual para imágenes
  chrome.contextMenus.create({
    id: "leer-qr-imagen",
    title: "Leer QR",
    contexts: ["image"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "leer-qr-imagen" && info.srcUrl) {
    // Asegurarse de codificar la URL de la imagen
    const encoded = encodeURIComponent(info.srcUrl);
    const target = `https://zgrafic.com/qr/?url=${encoded}`;
    // Abrir en una nueva pestaña
    chrome.tabs.create({ url: target });
  }
});
